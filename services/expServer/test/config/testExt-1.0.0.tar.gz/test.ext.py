import datetime
print datetime.datetime.strptime("7/17/2017", '%m/%d/%Y').strftime('%w')