def a():
    return 1