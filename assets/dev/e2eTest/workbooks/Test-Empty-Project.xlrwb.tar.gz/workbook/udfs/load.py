# PLEASE TAKE NOTE:

# UDFs can only support
# return values of
# type String.

# Function names that
# start with __ are
# considered private
# functions and will not
# be directly invokable.

def getQueryStateOutputNodes(fullPath, inStream):
    utf8Stream = Utf8Reader(inStream)
    def converToNum(n):
        return int(n)
    for line in utf8Stream:
        d = json.loads(line)
        nodes = d["query_state_output"]["nodes"]
        job_id = d["query_state_output"]["job_id"]
        job_start = d["query_state_output"]["job_start_timestamp_microsecs"]
        for node in nodes:
            node["job_id"] = job_id
            node["job_start_timestamp_microsecs"] = job_start
            rows = node["rows_per_node_in_cluster"].split(":")
            rows = list(map(converToNum, rows))
            skew = getSkew(rows)
            node["skew"] = skew
            yield node


def getSkew(rows):
    skewness = 0
    rowlen = len(rows)
    even = 1 / rowlen
    total = 0

    for val in rows:
        total += val

    if (total <= 1):
        # 1 row has no skewness
        skewness = 0
    elif (rowlen == 1):
        # one row has no skew
        skewness = 0
    else:
        rowPct = []
        for val in rows:
            rowPct.append(val / total)

        skewness = 0
        # the total skew
        for val in rowPct:
            skewness += abs(val - even)
        skewness = skewness * rowlen / (2 * (rowlen - 1))
        skewness = math.floor(skewness * 100)
        return skewness