def replaceFNF(val = None):
    if val is None:
        return ""
    else: 
        return val