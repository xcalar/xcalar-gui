# PLEASE TAKE NOTE:

# UDFs can only support
# return values of
# type String.

# Function names that
# start with __ are
# considered private
# functions and will not
# be directly invokable.

import json
from faker import Faker
def data_gene_faker(fullPath, inStream):
    fake = Faker()
    inObj = json.loads(inStream.read())
    numLocalRows = inObj["numRows"]
    startNum = inObj["startRow"]
    for ii in range(startNum, startNum+numLocalRows):
        rowDict = {}
        rowDict['Name'] = fake.name()
        rowDict['Address'] =fake.address()
        rowDict['CC_Number'] =  fake.credit_card_number()
        rowDict['State'] =fake.state()
        rowDict['City'] =fake.city()
        rowDict['Phone Number'] =fake.phone_number()
        rowDict['COuntry'] =fake.country()
        rowDict['Date of Birth'] =fake.date_of_birth()     
        yield rowDict   