
import codecs

Utf8Reader = codecs.getreader("utf-8")

def parse_scores(fullPath, inStream):
    """
        Parser Function written as a part of Xcalar Tutorial Workbook - 1 - Parsers
        parses the file student_scores.csv 
        inStream : Binary file stream.
        fullPath : Full path of the file being parsed.
    """
    utf8Stream = Utf8Reader(inStream) # converts binary stream to utf-8 text stream
    d = {} # dictionary which is updated and passed to Xcalar for each record extracted from data file
    for line in utf8Stream:
        tokens = line.split("|") # split pipe seperated string
        d["School Name"] = tokens[0].strip() 
        d["Student Name"] = tokens[1].strip()
        for class_grade in tokens[2].strip().split(" "):
            class_tokens = class_grade.split(":")
            d[class_tokens[0].strip()] = class_tokens[1].strip()
        yield d # pass one record at a time to  xcalar to append to the new table.

